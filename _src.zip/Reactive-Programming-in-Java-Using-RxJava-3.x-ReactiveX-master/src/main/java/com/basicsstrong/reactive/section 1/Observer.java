package com.basicsstrong.reactive.section1;

public interface Observer {
	
	public void update(String avail);

}
